PACMAN

Usage:
Run:
Given the questA.txt file, usage is given  below:

----------------------------------------------
python pacman.py <maze_text_file> <search_algorithm> 
----------------------------------------------

Example:
If the preferred search algorithm is DFS, ps dfs as the argument, as given below:
 >python pacman.py questA.txt dfs


Similarly for BFS:
>python pacman.py questA.txt bfs


Similarly for UCS:
>python pacman.py questA.txt ucs
